<template>
  <div class="card">
    <DataTable :value="employees" tableStyle="min-width: 50rem">
      <Column field="id" header="ID" sortable style="width: 10%"></Column>
      <Column field="name" header="Name" sortable style="width: 25%"></Column>
      <Column field="email" header="Email" sortable style="width: 25%"></Column>
      <Column field="department" header="Department" sortable style="width: 20%"></Column>
      <Column field="position" header="Position" sortable style="width: 20%"></Column>
      <Column field="salary" header="Salary" sortable style="width: 15%">
        <template #body="slotProps">
          ${{ slotProps.data.salary.toLocaleString() }}
        </template>
      </Column>
      <Column header="Status" style="width: 10%">
        <template #body="slotProps">
          <Tag :value="slotProps.data.status" :severity="getStatusSeverity(slotProps.data.status)" />
        </template>
      </Column>
    </DataTable>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import DataTable from 'primevue/datatable'
import Column from 'primevue/column'
import Tag from 'primevue/tag'

interface Employee {
  id: number
  name: string
  email: string
  department: string
  position: string
  salary: number
  status: string
}

const employees = ref<Employee[]>([
  {
    id: 1,
    name: 'John Doe',
    email: 'john.doe@company.com',
    department: 'Engineering',
    position: 'Senior Developer',
    salary: 95000,
    status: 'Active'
  },
  {
    id: 2,
    name: 'Jane Smith',
    email: 'jane.smith@company.com',
    department: 'Marketing',
    position: 'Marketing Manager',
    salary: 85000,
    status: 'Active'
  },
  {
    id: 3,
    name: 'Bob Johnson',
    email: 'bob.johnson@company.com',
    department: 'Sales',
    position: 'Sales Representative',
    salary: 65000,
    status: 'Active'
  },
  {
    id: 4,
    name: 'Alice Williams',
    email: 'alice.williams@company.com',
    department: 'Engineering',
    position: 'Lead Developer',
    salary: 110000,
    status: 'Active'
  },
  {
    id: 5,
    name: 'Charlie Brown',
    email: 'charlie.brown@company.com',
    department: 'HR',
    position: 'HR Specialist',
    salary: 70000,
    status: 'On Leave'
  },
  {
    id: 6,
    name: 'Diana Prince',
    email: 'diana.prince@company.com',
    department: 'Finance',
    position: 'Financial Analyst',
    salary: 80000,
    status: 'Active'
  },
  {
    id: 7,
    name: 'Ethan Hunt',
    email: 'ethan.hunt@company.com',
    department: 'Operations',
    position: 'Operations Manager',
    salary: 90000,
    status: 'Active'
  },
  {
    id: 8,
    name: 'Fiona Green',
    email: 'fiona.green@company.com',
    department: 'Engineering',
    position: 'Junior Developer',
    salary: 60000,
    status: 'Active'
  }
])

const getStatusSeverity = (status: string) => {
  switch (status) {
    case 'Active':
      return 'success'
    case 'On Leave':
      return 'warn'
    case 'Inactive':
      return 'danger'
    default:
      return 'info'
  }
}
</script>

<style scoped>
.card {
  padding: 2rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
</style>
